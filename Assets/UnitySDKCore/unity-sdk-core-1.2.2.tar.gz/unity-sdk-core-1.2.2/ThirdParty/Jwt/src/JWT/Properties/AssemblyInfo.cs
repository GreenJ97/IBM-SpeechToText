﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("JWT.Tests.Common")]
[assembly: InternalsVisibleTo("JWT.Tests.Core")]
[assembly: InternalsVisibleTo("JWT.Tests.NETFramework")]